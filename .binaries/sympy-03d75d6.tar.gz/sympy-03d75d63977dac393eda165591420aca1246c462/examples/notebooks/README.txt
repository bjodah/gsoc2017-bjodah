This directory contains `IPython`_ Notebooks. To open them, run ``ipython
notebook`` in this directory. This command will start IPython `notebook`_
server, and let your default browser connect to it.


.. _ipython: http://ipython.org/
.. _notebook: http://ipython.org/notebook.html
