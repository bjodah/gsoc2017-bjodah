===============
Gaussian Optics
===============

.. automodule:: sympy.physics.optics.gaussopt
   :members:
