.. _combinatorics-prufer:

Prufer Sequences
================

.. module:: sympy.combinatorics.prufer

.. autoclass:: Prufer
   :members:
