.. _combinatorics-named_groups:

Named Groups
============

.. module:: sympy.combinatorics.named_groups

.. autofunction:: SymmetricGroup

.. autofunction:: CyclicGroup

.. autofunction:: DihedralGroup

.. autofunction:: AlternatingGroup

.. autofunction:: AbelianGroup
